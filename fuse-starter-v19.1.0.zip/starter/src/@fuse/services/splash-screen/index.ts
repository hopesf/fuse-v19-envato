export * from '@fuse/services/splash-screen/public-api';
